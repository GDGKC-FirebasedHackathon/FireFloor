﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using System.Threading;
using System.Net;
using System.Net.Sockets;
using System.Text;

using System;

using Firebase;
using Firebase.Database;
using Firebase.Unity.Editor;

public class Matching_Handle
{
    public int n;
    public Socket s;
}

public class Thread_Match_Handle
{
    public Thread t;
    public Socket[] s = new Socket[6];
}

public class NetworkManager : MonoBehaviour {

    private static string ServerIP = "127.0.0.1";
    private static int ServerPORT = 7777;

    private byte Player_number = 1; // default;

    private volatile bool Thread_Stop = false;

    private byte MaxCard_Count = 63;
    
    List<Thread_Match_Handle> GameMatchList;
    Thread AcceptThread;
    System.Net.IPEndPoint ServerAddress;   
    Socket ServerSocket;

    void OnDestroy()
    {
        Thread_Stop = true;

        // Thread Close
        foreach (Thread_Match_Handle t in GameMatchList)
        {
            t.t.Interrupt();
            t.t.Abort();
        }
        AcceptThread.Interrupt();
        AcceptThread.Abort();

        // Socket Close
        ServerSocket.Close();
    }
    // Set up the Editor before calling into the realtime database.
   
    // Use this for initialization
    void Awake() {
        ServerAddress = new System.Net.IPEndPoint(System.Net.IPAddress.Parse(ServerIP), ServerPORT);
        // Socket Set
        ServerSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        ServerSocket.Bind(ServerAddress);
        ServerSocket.Listen(100);

        AcceptThread = new Thread(AcceptFunc);
        AcceptThread.Start();
    

    }

    private void FixedUpdate()
    {
        
    }
    void InitalizingServer()
    {
        
    }
    Thread StartMatching;
    void AcceptFunc()
    { 
        while(true)
        {
            Thread_Match_Handle TMH = new Thread_Match_Handle();

            for (int i = 0; i < 6; i++)
            {
                Debug.Log(i.ToString());
                TMH.s[i] = ServerSocket.Accept();
            }

            StartMatching = new Thread(new ParameterizedThreadStart(StartFunc));
            TMH.t = StartMatching;  
            StartMatching.Start(TMH);
            
            GameMatchList.Add(TMH);
        }
    }

    public void StartFunc(object socket_list)
    {
        Debug.Log("Test");
        Thread_Match_Handle Handle = (Thread_Match_Handle)socket_list;

        string Thread_Time = DateTime.Now.ToString();
        Thread_Time = Thread_Time.Replace('/', '-');
        try
        {
            DebugLog(Thread_Time, "게임이 시작되었습니다!");

            #region 플레이어 수
            int Players_Count;
            for (Players_Count = 0; Players_Count < 6; Players_Count++)
            {
                if (Handle.s[Players_Count] == null)
                {
                    break;
                }
            }
            
            DebugLog(Thread_Time, string.Format("플레이어 수 : {0}", Players_Count));
            #endregion

            #region 플레이어 카드 및 덤프 카드 정렬
            int D_Card_Length = 7;

            byte PerPlayerCard = (byte)(56 / Players_Count); // 플레이어마다 카드 갯수
           
            byte RemainderCardCount = (byte)(56 % Players_Count); // 나누고 남은 카드 갯수
            Debug.Log(" Debug.Log(RemainderCardCount);" + RemainderCardCount);
            int FirstPlayerCard = (byte)(PerPlayerCard + 1);
            if (RemainderCardCount != 0)
                RemainderCardCount--;
            else
                D_Card_Length--;

            byte[][] Player_Card = new byte[Players_Count][];
            Player_Card[0] = new byte[FirstPlayerCard];
            for (int temp = 1; temp < Players_Count; temp++)
            {
                Player_Card[temp] = new byte[PerPlayerCard];
            }

            D_Card_Length += RemainderCardCount;
            byte[] D_Card = new byte[D_Card_Length];
            #endregion
            DebugLog(Thread_Time, "카드를 섞고 있습니다!");
            #region 카드 섞기
            Queue<byte> Temp_Q = new Queue<byte>();
            List<byte> Temp_L = new List<byte>();

            for (int i = 0; i <= 8; i++)
                Temp_L.Add((byte)i);
            for (int i = 16; i <= 24; i++)
                Temp_L.Add((byte)i);
            for (int i = 32; i <= 40; i++)
                Temp_L.Add((byte)i);
            for (int i = 48; i <= 56; i++)
                Temp_L.Add((byte)i);
            for (int i = 64; i <= 72; i++)
                Temp_L.Add((byte)i);
            for (int i = 80; i <= 88; i++)
                Temp_L.Add((byte)i);
            for (int i = 96; i <= 104; i++)
                Temp_L.Add((byte)i);
            //Temp_L.Add((byte)112);
            //Temp_L.Add((byte)120);

            DebugLog(Thread_Time, "카드를 다 섞고, 배분중입니다...");

            while (Temp_L.Count > 0)
            {
                int random = 0;
                byte temp = Temp_L[random];
                Temp_L.RemoveAt(random);
                Temp_Q.Enqueue(temp);
            }
            Debug.Log("1");

            for (int i = 0; i < Players_Count; i++)
            {
                for (int j = 0; j < Player_Card[i].Length; j++)
                {
                    Player_Card[i][j] = Temp_Q.Dequeue();
                }
            }
            Debug.Log(D_Card.Length.ToString() + ", " + Temp_Q.Count.ToString());
            for (int i = 0; i < D_Card.Length; i++)
            {
                D_Card[i] = Temp_Q.Dequeue();
            }
            DebugLog(Thread_Time, "배분이 완료 되었습니다.");
            #endregion

            #region 모든 플레이어의 준비 시작을 알림
            DebugLog(Thread_Time, "플레이어들에게 경기 시작을 알립니다.");

            byte[] Ready = new byte[3] { 0, 0, (byte)Players_Count };
            for (int i = 0; i < Players_Count; i++)
            {
                Ready[1] = (byte)i;
                Debug.Log("i : " + i);
                Handle.s[i].Send(Ready, 0, 3, SocketFlags.None);
            }

            Debug.Log("Test");
            byte[][] Player_GraveCard = new byte[Players_Count][];

            for (int i = 0; i <Players_Count; i++)
            {
                Player_GraveCard[i] = new byte[MaxCard_Count];
                for (int j = 0; j < MaxCard_Count; j++)
                {
                    Debug.Log("j" + j + " MAX " + MaxCard_Count);
                    Player_GraveCard[i][j] = 255;
                }
            }

            DebugLog(Thread_Time, "플레이어들에게 자기들의 패를 전송합니다.");
            // 플레이어 들에게 자기들의 패를 전송
            byte[] D_Card_Temp = new byte[2] { 9, D_Card[0] };
            
            for (int i = 0; i < Players_Count; i++)
            {
                byte[] Temp = new byte[Player_Card[i].Length + 1];
                Temp[0] = 5;
                for(int j=0,z=1 ; j<Player_Card[i].Length;j++,z++)
                {
                    Temp[z] = Player_Card[i][j];
                }
                Handle.s[i].Send(Temp, 0, Temp.Length, SocketFlags.None);
               
                Handle.s[i].Send(D_Card_Temp, 0, 2, SocketFlags.None);
            }
            DebugLog(Thread_Time, "플레이어들에게 자기들의 패를 전송 완료하였습니다.");
            #endregion

            bool Loser = false;
            bool Winer = false;
            int Start = 0;
            int BeforeStart = 0;
            List<byte> PassLock = new List<byte>();
            PassLock.Clear();
            int DumpCardStart = 0;
            while (!Loser && !Winer)
            {
                BeforeStart = Start;
                DebugLog(Thread_Time, string.Format("{0} 플레이어로부터 데이터를 받고있습니다.", Start));
                byte[] recvByte = new byte[1024];
                int recvByte_Length = Handle.s[Start].Receive(recvByte, 0, recvByte.Length, SocketFlags.None);
                byte[] P_byte = new byte[recvByte_Length];
                for (int i = 0; i < P_byte.Length; i++)
                {
                    P_byte[i] = recvByte[i];
                }
                DebugLog(Thread_Time, "데이터를 받았습니다.");

                byte Target = P_byte[1];
                Start = Target;
                byte Card = P_byte[2];
                for (int i = 0; i < Player_Card[BeforeStart].Length; i++) // Black 뻄
                {
                    if (Player_Card[BeforeStart][i] == Card)
                    {
                        Player_Card[BeforeStart][i] = 254;
                        break;
                    }
                }
                byte Q = P_byte[3];
                DebugLog(Thread_Time, string.Format("정보 - 누구에게 {0}, 카드 {1}, 질문 {2}", P_byte[1].ToString(), P_byte[2].ToString(), P_byte[3].ToString()));
                int Check = 1; // 0 true, 1 false

                #region 카드가 true? false?
                if (Q == 2) // King
                {
                    if (Card == 8 || Card == 24 || Card == 40 || Card == 56 || Card == 72 || Card == 88 || Card == 104)
                        Check = 0;
                }
                //else if (Q == 3) // SubKing
                //{
                //    if (((0 <= Card) && (Card < 8)) ||
                //        ((16 <= Card) && (Card < 24)) ||
                //        ((32 <= Card) && (Card < 40)) ||
                //        ((48 <= Card) && (Card < 56)) ||
                //        ((64 <= Card) && (Card < 72)) ||
                //        ((80 <= Card) && (Card < 88)) ||
                //        ((96 <= Card) && (Card < 104)))
                //    {
                //        Check = 0;
                //    }
                //}
                else
                {
                    if (Q == 0)
                    {
                        if ((0 <= Card) && (Card <= 8))
                            Check = 0;
                    }
                    else if (Q == 16)
                    {
                        if ((16 <= Card) && (Card <= 24))
                            Check = 0;
                    }
                    else if (Q == 32)
                    {
                        if ((32 <= Card) && (Card <= 40))
                            Check = 0;
                    }
                    else if (Q == 48)
                    {
                        if ((48 <= Card) && (Card <= 56))
                            Check = 0;
                    }
                    else if (Q == 64)
                    {
                        if ((64 <= Card) && (Card <= 72))
                            Check = 0;
                    }
                    else if (Q == 80)
                    {
                        if ((80 <= Card) && (Card <= 88))
                            Check = 0;
                    }
                    else if (Q == 96)
                        if ((96 <= Card) && (Card <= 104))
                            Check = 0;
                }
                #endregion

                DebugLog(Thread_Time, "브로드 캐스트 중입니다...");
                #region 브로드 캐스트 - 타겟인 자는 Card 정보를 얻음.
                for (int i = 0; i < Players_Count; i++)
                {
                    if (i == Target)
                    {
                        P_byte[2] = Card;
                        Handle.s[i].Send(P_byte, 0, P_byte.Length, SocketFlags.None);
                    }
                    else
                    {
                        P_byte[2] = 0;
                        Handle.s[i].Send(P_byte, 0, P_byte.Length, SocketFlags.None);
                    }
                }
                DebugLog(Thread_Time, "브로드 캐스트 완료");
                #endregion

                #region Target의 응답을 받아옴
                DebugLog(Thread_Time, string.Format("{0}으로 부터 데이터를 받는중...", Start.ToString()));
                recvByte = new byte[1024];
                recvByte_Length = Handle.s[Start].Receive(recvByte, 0, recvByte.Length, SocketFlags.None);
                P_byte = new byte[recvByte_Length];
                for (int i = 0; i < P_byte.Length; i++)
                {
                    P_byte[i] = recvByte[i];
                }

                Target = P_byte[1];
                Start = Target;
                byte A = P_byte[2];
                DebugLog(Thread_Time, string.Format("{0}의 대답 - 타겟 : {0}, 응답 : {1}", P_byte[1].ToString(), P_byte[2].ToString()));
                #endregion

                #region Answer 검사
                int Final_Check = 1; // 0 true, 1 false
                if (A == 4) // Pass
                {
                    DebugLog(Thread_Time, "Pass");
                    PassLock.Add((byte)BeforeStart);
                    byte[] PassState = new byte[1 + PassLock.Count];
                    PassState[0] = (byte)8;
                    for (int i = 0, j = 1; i < PassLock.Count; i++, j++)
                    {
                        PassState[j] = PassLock[i];
                    }
                    for (int i = 0; i < Players_Count; i++)
                    {
                        Handle.s[i].Send(PassState, 0, PassState.Length, SocketFlags.None);
                    }
                    int f;
                    for (f = 0; f < Player_Card[Start].Length; f++)
                    {
                        if (Player_Card[Start][f] == 254) // 비어있는곳
                        {
                            Player_Card[Start][f] = Card;
                        }
                    }
                    if (f == (Player_Card[Start].Length - 1)) // 패가 가득참 - 배열을 백업하고 배열 넓이를 1 더한후 다시 대입 + Card값 대입
                    {
                        byte[] Temp = new byte[Player_Card[Start].Length];
                        for (int i = 0; i < Temp.Length; i++)
                        {
                            Temp[i] = Player_Card[Start][i];
                        }
                        Player_Card[Start] = new byte[Temp.Length + 1];
                        for (int i = 0; i < Temp.Length; i++)
                        {
                            Player_Card[Start][i] = Temp[i];
                        }
                        Player_Card[Start][Temp.Length] = Card;
                    }
                }
                else if (A == 1) // True
                {
                    DebugLog(Thread_Time, "Answer = true");
                    if (Check == 1)
                    {
                        Final_Check = 0;

                        for (int i = 0; i < Player_GraveCard[BeforeStart].Length; i++)
                        {
                            if (Player_GraveCard[BeforeStart][i] == 255)
                            {
                                Player_GraveCard[BeforeStart][i] = Card;
                                Player_GraveCard[BeforeStart][i + 1] = D_Card[DumpCardStart++];
                                BeforeStart = Start;
                                DebugLog(Thread_Time, "정답");
                                break;
                            }
                        }
                    }
                    else if (Check == 2)
                    {
                        Final_Check = 1;
                        for (int i = 0; i < Player_GraveCard[Start].Length; i++)
                        {
                            if (Player_GraveCard[Start][i] == 255)
                            {
                                Player_GraveCard[Start][i] = Card;
                                Player_GraveCard[Start][i + 1] = D_Card[DumpCardStart++];
                                Start = BeforeStart;
                                DebugLog(Thread_Time, "오답");
                                break;
                            }
                        }
                    }
                }
                else if (A == 2) // False
                {
                    DebugLog(Thread_Time, "Answer = false");
                    if (Check == 1)
                    {
                        Final_Check = 1;
                        for (int i = 0; i < Player_GraveCard[Start].Length; i++)
                        {
                            if (Player_GraveCard[Start][i] == 255)
                            {
                                Player_GraveCard[Start][i] = Card;
                                Player_GraveCard[Start][i + 1] = D_Card[DumpCardStart++];
                                Start = BeforeStart;
                                DebugLog(Thread_Time, "오답");
                                break;
                            }
                        }
                    }
                    else if (Check == 2)
                    {
                        Final_Check = 0;
                        for (int i = 0; i < Player_GraveCard[BeforeStart].Length; i++)
                        {
                            if (Player_GraveCard[BeforeStart][i] == 255)
                            {
                                Player_GraveCard[BeforeStart][i] = Card;
                                Player_GraveCard[BeforeStart][i + 1] = D_Card[DumpCardStart++];
                                BeforeStart = Start;
                                DebugLog(Thread_Time, "정답");
                                break;
                            }
                        }
                    }
                }
                if (A != 4) // !Pass
                {
                    DebugLog(Thread_Time, "Pass가 아니니. PassLock 초기화");
                    PassLock.Clear();
                }
                #endregion

                #region 패 갱신, 무덤 갱신
                // 패 갱신 6 무덤 갱신 3
                for (int i = 0; i < Players_Count; i++)
                {
                    byte[] Temp = new byte[Player_Card[i].Length + 1];
                    Temp[0] = (byte)5;
                    for (int j = 1, k = 0; j < Temp.Length; j++, k++)
                    {
                        Temp[j] = Player_Card[i][k];
                    }
                    Handle.s[i].Send(Temp, 0, Temp.Length, SocketFlags.None);
                    DebugLog(Thread_Time, string.Format("{0}의 패 갱신 : {1} ", i.ToString(), Encoding.Default.GetString(Temp).ToString()));

                    D_Card_Temp = new byte[2] { 9, D_Card[DumpCardStart] };
                    for (int j = 0; j < Players_Count; j++)
                    {
                        Handle.s[j].Send(D_Card_Temp, 0, 2, SocketFlags.None);
                    }
                }

                for (int i = 0; i < Players_Count; i++)
                {
                    int j = 0;
                    for (j = 0; j < Player_GraveCard[i].Length; j++)
                    {
                        if (Player_GraveCard[i][j] == 255)
                        {
                            break;
                        }
                    }


                    byte[] Temp = new byte[2 + j + 1];
                    Temp[0] = (byte)3;
                    Temp[1] = (byte)i;

                    for (int z = 2, b = 0; z < Temp.Length; z++, b++)
                    {
                        Temp[z] = Player_GraveCard[i][b];
                    }

                    for (int h = 0; h < Players_Count; h++)
                    {
                        Handle.s[h].Send(Temp, 0, Temp.Length, SocketFlags.None);
                    }
                    DebugLog(Thread_Time, string.Format("{0}의 무덤 패 갱신 : {1}", i.ToString(), Encoding.Default.GetString(Temp).ToString()));
                }
                #endregion

                #region 카드 갯수 갱신
                {
                    byte[] Temp = new byte[1 + (Players_Count * 2)];
                    // 4 , Player + Count
                    Temp[0] = 4;
                    for (int j = 1, z = 0; z < Players_Count; z++, j += 2)
                    {
                        Temp[j] = (byte)z;
                        Temp[j + 1] = (byte)Player_Card[z].Length;
                    }
                    for (int i = 0; i < Players_Count; i++)
                    {
                        Handle.s[i].Send(Temp, 0, Temp.Length, SocketFlags.None);
                    }
                    DebugLog(Thread_Time, string.Format("카드 갯수 갱신 : {1}", Encoding.Default.GetString(Temp).ToString()));
                }
                #endregion

                #region 계산 처리... 
                {
                    // 자신의 패의 수가 0개 일때. 승자()
                    for (int i = 0; i < Players_Count; i++)
                    {
                        //if (Player_Card[i].Length == 0) // 패가 0개일때 !
                        //{
                        //    Winer = true;
                        //    byte[] Winner = new byte[2] { 6, (byte)i };

                        //    for (int j = 0; j < Players_Count; j++)
                        //    {
                        //        Handle.s[j].Send(Winner, 0, Winner.Length, SocketFlags.None);
                        //    }
                        //    DebugLog(Thread_Time, string.Format("승자 : {0}", Winner[1].ToString()));
                        //}
                        if ((CheckSetCard(ref Player_GraveCard[i]) == true)||Player_Card[i].Length==0) // 무덤 패중에 4개이상 같은것이 존재할때
                        {
                            Loser = true;
                            byte[] Losser = new byte[2] { 7, (byte)i };

                            for (int j = 0; j < Players_Count; j++)
                            {
                                Handle.s[j].Send(Losser, 0, Losser.Length, SocketFlags.None);
                            }
                            DebugLog(Thread_Time, string.Format("패자 : {0}", Losser[1].ToString()));
                        }
                    }
                }
                #endregion
            }
            for (int i = 0; i < Players_Count; i++)
            {
                Handle.s[i].Shutdown(SocketShutdown.Both);
                Handle.s[i].Close();
            }
        }
        catch (Exception ex)
        {
            DebugLog(Thread_Time, ex.Message.ToString());
        }

        return;
    }


    bool CheckSetCard(ref byte[] cards)
    {
        Queue<byte>[] Q = new Queue<byte>[7];

        for(int i=1; i<cards.Length || cards[i]!=255; i++)
        {
            if((0<=cards[i])&&(cards[i]<=8)) // 박쥐
            {
                Q[0].Enqueue(cards[i]);
            }
            else if ((16 <= cards[i]) && (cards[i] <= 24)) // 바퀴벌레
            {
                Q[1].Enqueue(cards[i]);
            }
            else if ((32 <= cards[i]) && (cards[i] <= 40)) // 파리
            {
                Q[2].Enqueue(cards[i]);
            }
            else if ((48 <= cards[i]) && (cards[i] <= 56)) // 두꺼비
            {
                Q[3].Enqueue(cards[i]);
            }
            else if ((64 <= cards[i]) && (cards[i] <= 72)) // 노린재
            {
                Q[4].Enqueue(cards[i]);
            }
            else if ((80 <= cards[i]) && (cards[i] <= 88)) // 쥐
            {
                Q[5].Enqueue(cards[i]);
            }
            else if ((96 <= cards[i]) && (cards[i] <= 104)) // 전갈
            {
                Q[6].Enqueue(cards[i]);
            }
        }

        for (int temp = 0; temp < 7; temp++)
        {
            if(Q[temp].Count>=4)
            {
                return true;
            }
        }
        return false;
    }

    void DebugLog(string Thread_Time,string message)
    {
       //  FirebaseApp.DefaultInstance.SetEditorDatabaseUrl("https://gamedb-8b066.firebaseio.com/");
        // Get the root reference location of the database.
       //  DatabaseReference reference = FirebaseDatabase.DefaultInstance.RootReference.Child("GameDataLogs").Child(Thread_Time);
        string TimeNow = DateTime.Now.ToString();
        TimeNow = TimeNow.Replace('/', '-');
        string LogMessage = message;
       
        // Write server log in database
        // reference.Child(TimeNow).SetValueAsync(LogMessage);

        Debug.Log(Thread_Time + " # " + TimeNow + " - " + message);
    }
}
